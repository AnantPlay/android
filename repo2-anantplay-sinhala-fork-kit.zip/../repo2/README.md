# anantplay-sinhala — fork kit

Surgical patch kit that turns `AnantPlay/android` **v2.23.1** into a Sinhala-subtitle-first build. Two files are all you need: the patch and the font.

```
patches/anantplay-sinhala.patch   # git diff, proven to apply cleanly onto v2.23.1 (git apply --check PASS)
assets/NotoSansSinhala-Regular.ttf # bundled in the patch's assets/ add; kept here for rebuilds (OFL)
PATCH_SPEC_V2.md                   # exact file:line breakdown of all 4 patches with v2.23.1 source proofs
FORK_WORKFLOW_NOTES.md             # Arena.ai CI recipe: build.sh, keystore, GitHub Actions release
```

## Apply (ස්ථාපනය)

```bash
git clone https://github.com/AnantPlay/android anantplay-sinhala && cd anantplay-sinhala
git checkout v2.23.1
git apply --check ../patches/anantplay-sinhala.patch   # must pass
git apply ../patches/anantplay-sinhala.patch
```

The four changes (details + file:line proofs in `PATCH_SPEC_V2.md`):

1. **`Subs.java`** — configurable Sinhala addon URL (Settings), `si`↔`sin` ISO 639 normalization so zero rows drop, addon-first search & auto-pick.
2. **`SubFetch.java`** — `sin` → UTF-8 charset; HTTP 202 → `RetryLaterException` (non-blocking retry).
3. **`PlayerActivity.java`** — bundled Noto Sans Sinhala on the subtitle TextView (no more tofu), "Translating to Sinhala…" Toast on 202 with a 10 s auto-retry, fine ±0.25 s timing row.
4. **`Update.java`** — updater points at `dictationb1/anantplay-sinhala` releases so upstream updates never collide with the fork's signing key.

No RAR code in the fork: the companion Worker addon (see `srilanka-sinhala-subs-addon`) always serves extracted UTF-8 `.srt`.
