# FORK_WORKFLOW_NOTES — building & releasing `dictationb1/anantplay-sinhala`

Exact instructions for Arena.ai (or any CI) to turn the patch kit into signed Phone + TV APKs. Everything below matches upstream's Gradle-free pipeline: `build.sh` + `.github/workflows/build.yml` / `release.yml` (read from the v2.23.1 tree; upstream builds both APKs with plain SDK tools, no Gradle).

## 0 · One-time repo setup

```bash
git clone https://github.com/AnantPlay/android anantplay-sinhala
cd anantplay-sinhala
git checkout v2.23.1
git apply --check ../patches/anantplay-sinhala.patch   # must print nothing and exit 0 (proven in sandbox)
git apply ../patches/anantplay-sinhala.patch
git remote set-url origin https://github.com/dictationb1/anantplay-sinhala.git
git push -u origin main   # or a branch; the patch also carries assets/NotoSansSinhala-Regular.ttf
```

## 1 · The signing key (critical fork rule)

Upstream's `build.sh:20-25` **creates** `release.jks` with a random password if absent (PKCS12, alias `weblock`, RSA-4096, CN=WebLock). For the fork:

1. On the first CI runner, generate the key once and upload it as GitHub **Actions secrets**, not as repo files:
   - `KEYSTORE_BASE64` — `base64 -w0 release.jks`
   - `KEYSTORE_PASSWORD` — contents of `release.pass`
2. Back both up: an already-installed fork APK can only be updated by APKs signed with the **same key** (`Update.java:24` relies on this; a mismatch makes Android's installer reject the update).
3. Because the key differs from upstream's, redirecting `Update.java:26` to this repo is mandatory — upstream releases would otherwise be shown but fail to install.

## 2 · Building in GitHub Actions (upstream's exact recipe)

Upstream `.github/workflows/build.yml` provisions the Android SDK + JDK 17+, then runs `./build.sh`, which:

- compiles `src/` with `aapt2 compile --dir res` + `aapt2 link … --java build` (`build.sh:26-33`),
- builds the WARP helper via `warp/build.sh` (needs Go),
- runs `scripts/fetch-assets.sh` for the ad blocklist,
- produces `AnantPlay-TV-v<version>.apk` and `AnantPlay-Android-v<version>.apk`, signing with `release.jks`,
- flavors: `build/flavor-tv/flavor` = `tv` vs `android` — the asset `flavor` file `App.java:66-67` reads to route updates.

Minimal workflow for the fork (add to `.github/workflows/` in the forked repo):

```yaml
name: release
on:
  push:
    tags: ["v*"]
jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-java@v4
        with: { distribution: temurin, java-version: 17 }
      - uses: android-actions/setup-android@v3
      - uses: actions/setup-go@v5
        with: { go-version: stable }        # warp/build.sh needs Go
      - name: Restore fork keystore
        run: |
          echo "${{ secrets.KEYSTORE_BASE64 }}" | base64 -d > release.jks
          echo "${{ secrets.KEYSTORE_PASSWORD }}" > release.pass
      - name: Build both APKs
        run: VERSION_NAME=${GITHUB_REF_NAME#v} VERSION_CODE=$(date +%s%5) ./build.sh
        env: { ANDROID_HOME: ${{ env.ANDROID_HOME }} }
      - uses: softprops/action-gh-release@v2
        with:
          files: |
            AnantPlay-TV-v*.apk
            AnantPlay-Android-v*.apk
```

Upload names must keep upstream's `-TV-` / `-Android-` markers (`Update.java:87-93` filters assets by them). Tag format `vX.Y.Z`; `Update.newer()` (`Update.java:127-130`) compares dotted triples, so version the fork as `2.23.1` → `2.23.2`… continuing upstream's series.

## 3 · Release checklist per version

1. Bump `CHANGELOG.md` (upstream keeps only the current version's notes — `Update.check()` collects every release newer than installed for the notes dialog, `Update.java:78-84`).
2. Tag `v<version>` → the workflow builds + attaches both APKs.
3. Sanity-check on-device: Settings → Subtitles shows "Sinhala addon: Default (Sri Lanka Sinhala Subtitles)"; playing a Sinhala-subtitled movie shows Sinhala glyphs (not tofu) in the player; `Timing (fine)` ±0.25 s row appears in the player's Subtitles panel.
4. In-app update: the hourly job (`Update.java:49`) will find the new release on **this fork's** repo only.

## 4 · Wiring the addon

The patch's `SIN_ADDON_DEFAULT` is `https://sin-subs.YOUR-WORKER.workers.dev` — replace it (search/replace in `src/me/champdev/weblock/Subs.java`) with your deployed Worker URL from repo1 before building, or leave it and let users paste their own in Settings → Subtitles → "Sinhala addon" (it writes the `subAddonUrl` pref; an empty value falls back to the default).

## 5 · Later: retire the fork

When the four patches are upstreamed as a PR against `AnantPlay/android` (recommended after a few weeks of stable operation), delete the fork and its tag stream; users move back to upstream updates, keeping the same addon URL in Settings.

## Sandbox proofs behind these notes

- `git apply --check` on a pristine `v2.23.1` worktree: **PASS** (7 files checked).
- Real `git apply` onto a second pristine worktree, then `diff -r` against the compile-tested tree: **byte-identical**.
- javac-21 syntax check of all patched files: error profile identical to pristine upstream (all residual errors are pre-existing androidx/media3 symbol references, same lines before and after).
