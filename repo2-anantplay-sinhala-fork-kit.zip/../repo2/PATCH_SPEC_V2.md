# PATCH_SPEC_V2 — AnantPlay Sinhala Fork (v2.23.1 base)

Four surgical patches, **`git apply --check` PROVEN against the pristine `v2.23.1` tag** (7 files, +122/−6). Every `file:line` below was verified by reading the cloned `AnantPlay/android` repo at commit `be74df2` (tag `v2.23.1`), and every patched file compile-checks exactly as clean as upstream (javac 21 against android-34; residual errors are the pre-existing androidx/media3 symbols only, identical count before and after patching).

The patch lives at `patches/anantplay-sinhala.patch`; apply it onto a fresh fork of `AnantPlay/android` at `v2.23.1`:

```bash
git clone https://github.com/AnantPlay/android anantplay-sinhala && cd anantplay-sinhala
git checkout v2.23.1
git apply --check patches/anantplay-sinhala.patch   # passes
git apply patches/anantplay-sinhala.patch
cp assets/NotoSansSinhala-Regular.ttf assets/ 2>/dev/null || true   # font ships inside the patch already
```

---

## The four changes

### 1 · `Subs.java` — configurable addon, si↔sin normalization, addon-first auto-pick

| What | Where (post-patch) | Proof from the v2.23.1 source |
| --- | --- | --- |
| `SIN_ADDON_DEFAULT` constant + `addonUrl()` reading pref `subAddonUrl` | `Subs.java:16-32` | new code after `BASE` (`Subs.java:14` upstream) |
| `sinCode()` maps `si`/`sinh`/`si-lk` → `sin` (ISO 639-2/B) | `Subs.java:26-30` | upstream filters with **exact** `osCode(s.lang).equals(code)` in `search()` (`Subs.java:71`) — a `si` row would be silently dropped; this is the exact-match flaw the audit flagged |
| `find(imdb,s,e)` now asks **our addon first** (`onlyLang="sin"`), falls back to upstream BASE | `Subs.java:517-535` | replaces upstream `find()` (`Subs.java:478-497`) which hardcodes `BASE` |
| relative `/download/...` URLs resolved against the serving addon's origin; `source` label "Sinhala" | `Subs.java:530-533` | upstream rows carry absolute URLs only |
| `search()` IOException fallback keeps `sin` rows whatever spelling the addon used | `Subs.java:93-99` | upstream `Subs.java:70-72` |
| Settings rows: "Timing (fine)" ±250 ms + "Sinhala addon" URL editor in the Subtitles panel | `Subs.java:250-268` | reuses upstream `row()` (`Subs.java:426`) and `pickName()` (`Subs.java:382`) helpers |

The addon-first path also feeds `PlayerActivity.autoSubs()` (`PlayerActivity.java:2262-2271` post-patch): when the preferred language is Sinhala, the fork's addon is queried **before** OpenSubtitles, and row #1 (the Worker's `rank()` winner: human `sin` > auto-translated) auto-loads when `subAuto` is on.

### 2 · `SubFetch.java` — `sin` → UTF-8, HTTP 202 retry

| What | Where (post-patch) | Proof |
| --- | --- | --- |
| `forLang()` switch now normalizes via `Subs.sinCode(lang)` and `case "sin": n = "UTF-8"` | `SubFetch.java:167-168` | upstream `forLang()` default is **windows-1252** for unknown codes (`SubFetch.java:157-186`); Sinhala files are UTF-8 (BOM) — live-verified on piratelk + zoom.lk bytes |
| 202 detection: a small body mentioning translation/202/poll becomes `b = null` → `RetryLaterException` | `SubFetch.java:46-53, 56` | upstream `fetch()` reads the stream blind (`Warp.connect` never inspects status, `Warp.java:215-224`); a 202 HTML body would fail the `-->` sniff in upstream and just error out |
| `RetryLaterException` (extends IOException) | `SubFetch.java:192-195` | new |

Why this design: `Warp.open()` returns `getInputStream()` of whatever status arrived, and upstream's only guard is `t.contains("-->")` after decoding (`SubFetch.java:76`). A 202 from our Worker carries a tiny human-readable body ("translation started — poll again in ~10 s"), which this patch recognizes *before* that sniff and converts into a typed retry signal. **No RAR handling was added to the fork** — the addon's `/download/<token>.srt` always delivers clean extracted UTF-8 SRT, so `SubFetch` needs zero new archive code (this was the audit's "remove RAR from the fork" directive).

### 3 · `PlayerActivity.java` — Sinhala font, 202 Toast, fine timing

| What | Where (post-patch) | Proof |
| --- | --- | --- |
| `addSubtitle()` catches `RetryLaterException`, Toasts `player_subs_translating` ("Translating to Sinhala… ready in ~15 s"), retries once after 10 s via `App.main.postDelayed` — playback never blocked | `PlayerActivity.java:2349-2360` | upstream `addSubtitle()` (`PlayerActivity.java:2329-2341`) had a single IOException → "failed" toast |
| `activeSubLang` field set in `showSubtitle()` | `PlayerActivity.java:2381` + `:365` | upstream never tracked the file's language for styling |
| `placeSubtitle()` loads `assets/NotoSansSinhala-Regular.ttf` onto the `subtitle` TextView when the language is `sin`, with 20 sp (vs 22 sp Latin) for the taller Sinhala glyphs | `PlayerActivity.java:371-383` | upstream `placeSubtitle()` (`PlayerActivity.java:365-372`) styles a plain `TextView` created at `PlayerActivity.java:396` — on many TV builds the default sans has no Sinhala glyphs → tofu boxes |

The font file ships as `assets/NotoSansSinhala-Regular.ttf` inside the patch (Bin 154,912 bytes, OFL-licensed Noto). `build.sh` already passes `-A assets` to aapt2 (`build.sh:27-33`), so it is packaged with no workflow change. Bold was dropped deliberately: the fork renders subtitles through a single-weight TextView.

### 4 · `Update.java` — updater redirect

| What | Where | Proof |
| --- | --- | --- |
| `API` → `https://api.github.com/repos/dictationb1/anantplay-sinhala/releases?per_page=15` | `Update.java:26` | upstream constant `AnantPlay/android` (`Update.java:26`) |

This is the **only** line changed in the file. Upstream's whole update path flows from this constant: `check()` (`Update.java:73-105`) reads releases, picks the flavor-matching APK (`-TV-`/`-Android-`, `Update.java:88-93`), stores `updateUrl` pref; `install()` (`Update.java:143-199`) streams it into a `PackageInstaller` session. Redirecting the repo id makes the hourly `JobScheduler` check + boot receiver (`Update.java:49-50`) look at the fork's releases only, so an upstream `2.23.2` can never overwrite a fork-signed APK (Android rejects a different signing key as an update — and upstream builds with *their* `release.jks` created by `build.sh:20-25`, which the fork cannot have). One caveat kept from upstream: there is **no SHA-256/signature verification in `Update.java`** (it relies on Android's package-install signature check, `Update.java:24` comment) — if you want a hard hash pin, add it in `check()` where the asset URL is chosen.

### Strings

- `res/values/strings_player.xml:116` — `player_subs_translating` (202 Toast)
- `res/values/strings_home.xml:153-155` — `subs_timing_fine`, `subs_addon`, `subs_addon_default`

---

## What was intentionally NOT patched

- **RAR in `SubFetch.java`** — the server always serves extracted `.srt`; keeping the fork thin.
- `SubOs.java`, `SubSync.java`, `SpeechMeter.java`, `Home.java`, the Gradle-free `build.sh`, CI workflows — untouched; the on-device audio sync (`SubSync` ±240 s) continues to be Layer 2 of the sync story.
- `sinhalasub.lk` support — live re-audit found login-gated `/links/<token>/` interstitials; excluded from v1 sources on both sides.
